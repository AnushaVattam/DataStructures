To compile the "Assignment 4" (Experiment).
$  gcc  experiment.cpp

To execute 
$ ./a.out
 By entering different k , array1 size m , array2 size n values  , the results could be observed.


Could Execute  in Code::Blocks as well , as  if  you build and run  . 
By entering different k , array1 size m , array2 size n values  , the results could be observed.


