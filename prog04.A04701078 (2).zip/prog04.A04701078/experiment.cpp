#include <iostream>
#include <cstdlib>   // for srand and rand
#include <ctime>// for time
#include <ctime>

using namespace std;

int search1(  int[],  int,   int[], int );  // search function to search the larger table in the smaller table
int search2(  int[],  int,   int[], int );  // search function to sort the larger table, and binary search on the larger table in the small table
int search3(  int[],  int,   int[], int );  //search function to sort the smaller table, and binary search on the larger table in the large table
int search4(  int[],  int,   int[], int );


int main()
{
    int k,m, n;                             // user enters the values of k,m,n.
    cout << "Enter the Size k " << endl;
    cin >> k ;
    cout << "Enter the Size  m of the array1[m],less than k value"<<endl;
    cin >> m ;
    cout << "Enter the Size  n of the array2[n],less than k value"<<endl;
    cin >> n;
    int array1[m],array2[n];
    cout << endl;

srand(time(NULL));                          // initialize random seed
int r,r1,l,exists=0;
for (int i=0; i<m;i++)
                                            // Permute numbers in array
{
    do{
     r  =  rand()%(k);
     exists=0;
     for(l=0;l<i;l++)

     {
         if(array1[l]==r)
         {
             exists=1;
         }
     }
     if(exists==0)
     {
        break;
     }
     }while(exists==1);
    array1[i] = r;

     cout<< array1[i]<<" ";


}
cout<<endl;
for (int i=0; i<m; i++)                     // To shuffle the values in the array
{
  int p = i+rand()%(m-i);
   int temp = array1[i];
     array1[i] = array1[p];
    array1[p] = temp;
}
cout<< "shuffled values :"<< endl;
for (int i=0; i<m; i++)
{


    cout<< array1[i]<< " ";

}
cout<<endl;


for (int j=0; j< n;j++)              // permutate the array
{
     do{
     r1  =  rand()%(k);
     exists=0;
     for(l=0;l<j;l++)

     {
         if(array2[l]==r1)
         {
             exists=1;
         }
     }
     if(exists==0)
     {
        break;
     }
     }while(exists==1);
    array2[j]=r1;
    cout<< array2[j]<<"  ";

}


cout<<endl;
for (int i=0; i<n; i++)                    // To shuffle the values in the array
{
  int z = i+rand()%(n-i);
   int temp = array2[i];
     array2[i] = array2[z];
    array2[z] = temp;
}
cout<< "shuffled values :"<< endl;
for (int i=0; i<n; i++)
{

cout<< array2[i]<< " ";

}
cout<<endl;

search1(array1,m,array2,n);
if(m<n)
{
   search2(array1,m,array2,n);
}
else{
  search3(array1,m,array2,n);
}



search4(array1,m,array2,n);
return 0;

}


clock_t begin = clock();

int search1(int array1[],int m, int array2[],int n) // search function
{
int  c=0,snum=0;


    if(m<n)
    {
        for(int i=0;i<m;i++)
        {
            snum=array1[i];
            for(int j=0;j<n; j++)
            {
                if(array2[j]==snum)
                {
                    c=c+1;
                }
            }



       }
       cout<<"count:" << c<< endl;
    }
    else if(m>n)
{
       for(int i=0;i<n;i++)
        {
            snum=array2[i];
            for(int j=0;j<m; j++)
            {
                if(array1[j]==snum)
                {
                    c=c+1;
                }
            }
        }
   cout<<"count:" << c<< endl;
    }

clock_t end = clock();
double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
cout << "Elapsed time: " << elapsed_secs << " seconds." << endl;       // time elapsed
return c;

}


int search2(int array1[],int m, int array2[],int n)                  // search function
{
int c=0;
int i=0,j=0, temp;

    int array2dup[n];
       for(i=0;i<n;i++)
       {
               array2dup[i]=array2[i];
               cout << array2dup[i]<<"   ";
       }
       cout<< endl;

    for(int i2=0; i2<n; i2++)
   {
     for( j=0; j<n; j++)
     {
        //Swapping element in if statement
           if(array2dup[i2]<array2dup[j])
       {
        temp=array2dup[j];
        array2dup[j]=array2dup[i2];
        array2dup[i2]=temp;
       }
     }
   }
     cout<<"sorted array:"<<endl;
      for(j=0; j<n; j++)
     {
        //Swapping element in if statement
        cout<<array2dup[j]<<"   ";
     }
cout<<endl;
clock_t begin2 = clock();
        //binary search
        c =0;
        for(j=0;j<m ;j++)
        {
         int first =0,last =n-1,middle ;
       int  position= -1;
        bool found= false;
        while (! found&&first <=last)
        {
            middle = (first+last)/2;
            if(array2dup[middle]==array1[j] )
            {
                found = true;
                position =middle;
                c++;

            }
            else if (array2dup[middle]> array1[j])
                last = middle-1;
            else
                first = middle +1;
        }

        }
        clock_t end2 = clock();
        cout<< "clock begin :"<< begin2 <<endl;
        cout<< "clock end :"<< end2 <<endl;
        cout<< "count :"<< c <<endl;




double elapsed_secs = double(end2 - begin2) / CLOCKS_PER_SEC;
cout << "Elapsed time: " << elapsed_secs << " seconds." << endl;   // time elapsed
return c;

}


int search3(int array1[],int m, int array2[],int n)            // search 3 function
{
int c=0;
int i=0,j=0, temp,array1dup[m];
//clock_t tem=clock();
       for(i=0;i<m;i++)
       {
               array1dup[i]=array1[i];
               cout << array1dup[i]<<"   ";
       }
       cout<< endl;

    for(int i2=0; i2<m; i2++)
   {
     for( j=0; j<m ; j++)
     {
        //Swapping element in if statement
           if(array1dup[i2]<array1dup[j])
       {
        temp=array1dup[j];
        array1dup[j]=array1dup[i2];
        array1dup[i2]=temp;
       }
     }
   }
     cout<<"sorted array:"<<endl;
      for(j=0; j<m; j++)
     {
        //Swapping element in if statement
        cout<<array1dup[j]<<"   ";
     }
cout<<endl;

                                                                 //binary search
         c =0;

         clock_t begin1 = clock();

        for(j=0;j<n ;j++)
        {
         int first =0,last =m-1,middle ;
         int position= -1;
        bool found= false;
        while (! found&&first <=last)
        {
            middle = (first+last)/2;
            if(array1dup[middle]==array2[j] )
            {
                found = true;
                position =middle;
                c++;

            }
            else if (array1dup[middle]> array2[j])
                last = middle-1;
            else
                first = middle +1;
        }

        }
        clock_t end1 = clock();
        cout<< "clock begin :"<< begin1 <<endl;
        cout<< "clock end :"<< end1 <<endl;
        cout<< "count :"<< c <<endl;




double elapsed_secs = double(end1 - begin1) / CLOCKS_PER_SEC;
cout << "Elapsed time: " << elapsed_secs << " seconds." << endl;

/* elapsed_secs = double(end1 - tem) / CLOCKS_PER_SEC;
cout << "start to end Elapsed time: " << elapsed_secs << " seconds." << endl;*/
return c;
}

int search4 (int array1[],int m, int array2[],int n)
{
int c=0;
int i2,i=0,j=0, temp,array1dup[m],array2dup[n];
//clock_t tem=clock();
cout <<"array1dup :    ";
       for(i=0;i<m;i++)
       {
               array1dup[i]=array1[i];
               cout << array1dup[i]<<"   ";
       }
       cout<< endl;
 cout <<"array2dup :    ";
         for(i=0;i<n;i++)
       {
               array2dup[i]=array2[i];
               cout << array2dup[i]<<"   ";
       }
       cout<< endl;

    for(i2=0; i2<m; i2++)
   {
     for( j=0; j<m ; j++)
     {
        //Swapping element in if statement
           if(array1dup[i2]<array1dup[j])
       {
        temp=array1dup[j];
        array1dup[j]=array1dup[i2];
        array1dup[i2]=temp;
       }
     }
   }
     cout<<"sorted array:"<<endl;
      for(j=0; j<m; j++)
     {
        //Swapping element in if statement
        cout<<array1dup[j]<<"   ";
     }
cout<<endl;


 for(i2=0; i2<n; i2++)
   {
     for( j=0; j<n; j++)
     {
        //Swapping element in if statement
           if(array2dup[i2]<array2dup[j])
       {
        temp=array2dup[j];
        array2dup[j]=array2dup[i2];
        array2dup[i2]=temp;
       }
     }
   }
     cout<<"sorted array:"<<endl;
      for(j=0; j<n; j++)
     {
        //Swapping element in if statement
        cout<<array2dup[j]<<"   ";
     }
cout<<endl;

       // Merge sort to find common values//

       i=0;
       j=0;
       c=0;
       clock_t bg=clock();
       while(i<m&&j<n)
       {
           if(array1dup[i]==array2dup[j])
           {
               c=c+1;
               i++;
               j++;
           }
           else if(j==n-1&&i!=m-1)
           {
               j=0;
               i++;
           }
           else
           {
               j++;
           }
       }
       clock_t end3=clock();
        cout<< "clock begin :"<< bg <<endl;
        cout<< "clock end :"<< end3 <<endl;
        cout<< "count :"<< c <<endl;




double elapsed_secs = double(end3 - bg) / CLOCKS_PER_SEC;
cout << "Elapsed time: " << elapsed_secs << " seconds." << endl;
return c;
}
